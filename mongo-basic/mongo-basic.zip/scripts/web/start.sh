#!/bin/sh

service httpd start 
